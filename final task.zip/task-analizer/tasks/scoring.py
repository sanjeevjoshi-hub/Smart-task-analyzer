from datetime import datetime, date

def calculate_task_score(task):
    today = date.today()
    score = 0

    if isinstance(task['due_date'], str):
        task['due_date'] = datetime.strptime(task['due_date'], "%Y-%m-%d").date()

    days_left = (task['due_date'] - today).days

    if days_left < 0:
        score += 100
    elif days_left <= 3:
        score += 50

    score += task.get('importance', 5) * 5

    if task.get('estimated_hours', 3) < 2:
        score += 10

    return score
