import json
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .scoring import calculate_task_score


@csrf_exempt
def analyze_tasks(request):
    if request.method == "POST":
        tasks = json.loads(request.body)

        for t in tasks:
            t['score'] = calculate_task_score(t)

        sorted_tasks = sorted(tasks, key=lambda x: x['score'], reverse=True)
        return JsonResponse(sorted_tasks, safe=False)

    return JsonResponse({"error": "POST only"}, status=400)


@csrf_exempt
def suggest_tasks(request):
    sample = [
        {"title": "Study Math", "due_date": "2025-12-01", "importance": 8, "estimated_hours": 2},
        {"title": "Finish Homework", "due_date": "2025-11-30", "importance": 10, "estimated_hours": 3},
        {"title": "Clean Room", "due_date": "2025-12-10", "importance": 3, "estimated_hours": 1},
    ]

    for t in sample:
        t['score'] = calculate_task_score(t)

    top3 = sorted(sample, key=lambda x: x['score'], reverse=True)[:3]
    return JsonResponse(top3, safe=False)
