async function analyzeTasks() {
    const text = document.getElementById("taskInput").value;

    try {
        const tasks = JSON.parse(text);

        const resp = await fetch("http://127.0.0.1:8000/api/tasks/analyze/", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(tasks)
        });

        const data = await resp.json();
        displayResults(data);

    } catch (err) {
        alert("Invalid JSON format!");
    }
}

function displayResults(tasks) {
    const box = document.getElementById("results");
    box.innerHTML = "";

    tasks.forEach(t => {
        let priorityClass = "low";
        if (t.score >= 80) priorityClass = "high";
        else if (t.score >= 50) priorityClass = "medium";

        box.innerHTML += `
            <div class="task-card ${priorityClass}">
                <h3>${t.title}</h3>
                <p>Due: ${t.due_date}</p>
                <p>Importance: ${t.importance}</p>
                <p>Estimated Hours: ${t.estimated_hours}</p>
                <p><b>Score: ${t.score}</b></p>
            </div>
        `;
    });
}
