Smart Task Analyzer
Overview

The Smart Task Analyzer is a mini web application designed to help users prioritize tasks efficiently. It takes a list of tasks with attributes such as due date, importance, and estimated effort, calculates a priority score using a custom algorithm, and displays them in a user-friendly interface.

The project demonstrates full-stack development using Django for the backend and Vanilla JavaScript + HTML + CSS for the frontend.

Features

Accepts multiple tasks in JSON format.

Calculates a priority score based on:

Urgency (how soon the task is due)

Importance (user-defined scale)

Effort (short tasks get a bonus)

Sorts tasks in descending priority.

Provides color-coded task cards for visual priority cues:

Red → High priority

Orange → Medium priority

Green → Low priority

Handles edge cases such as overdue tasks or missing fields.

Tech Stack

Backend: Python 3.8+, Django 4.x

Frontend: HTML5, CSS3, Vanilla JavaScript

Database: SQLite (default Django database)

Development Environment: VS Code / PyCharm / Sublime Text

Installation & Setup
1. Clone the repository
git clone <your-repo-link>
cd task-analyzer

2. Create a virtual environment
python -m venv venv


Activate the virtual environment:

Windows (PowerShell):

venv\Scripts\Activate.ps1


If you get an execution policy error, run:

Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass


Mac/Linux:

source venv/bin/activate

3. Install dependencies
pip install django

4. Apply database migrations
python manage.py makemigrations
python manage.py migrate

Running the Application
1. Start the Django server
python manage.py runserver


You should see:

Starting development server at http://127.0.0.1:8000/

2. Open the Frontend

Open your browser and go to frontend/index.html (or serve it via Django templates for better compatibility).

Paste your tasks in JSON format and click Analyze.

JSON Input Format

The frontend accepts an array of task objects:

[
  {
    "title": "Finish Math Homework",
    "due_date": "2025-12-01",
    "importance": 9,
    "estimated_hours": 3
  },
  {
    "title": "Buy Groceries",
    "due_date": "2025-11-29",
    "importance": 4,
    "estimated_hours": 1
  }
]


Fields:

Field	Type	Description
title	String	Task name
due_date	String	YYYY-MM-DD format
importance	Int	Scale 1-10
estimated_hours	Int	Estimated effort in hours
Scoring Algorithm

The backend calculates a priority score using:

Urgency

Overdue tasks → +100 points

Tasks due in 3 days or less → +50 points

Importance

Score = importance * 5

Effort (Quick Wins)

Tasks with estimated_hours < 2 → +10 points

Higher score = higher priority.

Folder Structure
task-analyzer/
├── backend/                  # Django project
│   ├── settings.py
│   └── urls.py
├── tasks/                    # Django app
│   ├── models.py
│   ├── scoring.py
│   ├── views.py
│   └── urls.py
├── frontend/                 # Frontend files
│   ├── index.html
│   ├── styles.css
│   └── script.js
├── manage.py
├── db.sqlite3
└── requirements.txt

Example

Input JSON:

[
  {
    "title": "Submit Assignment",
    "due_date": "2025-12-01",
    "importance": 9,
    "estimated_hours": 3
  },
  {
    "title": "Buy Milk",
    "due_date": "2025-11-29",
    "importance": 3,
    "estimated_hours": 1
  }
]


Output (Frontend will show sorted cards with scores):

Task	Score
Submit Assignment	55
Buy Milk	65

Note: Scores are automatically calculated by backend.

Edge Case Handling

Missing importance → defaults to 5

Missing estimated_hours → defaults to 3

Past due dates → gets maximum urgency score

Empty JSON → frontend shows alert “Invalid JSON format!”

Future Improvements

Add user authentication to save tasks.

Add task dependencies for smarter prioritization.

Add drag-and-drop UI for manual task ordering.

Deploy using Docker or Heroku for online access.

Author

Name: Sanjeev joshi

Email: sanjeevjoshi051@gmail.com

GitHub: https://github.com/sanjeevjoshi-hub/My-Profile